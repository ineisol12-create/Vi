# Our Song — GitHub Pages

A no-framework, GitHub Pages-ready romantic music page.

## Password

The password is:

`Love`

It is case-sensitive.

## Song

The supplied audio is included locally as:

`assets/song.mp3`

Metadata in `script.js`:

- Title: You Belong With Me
- Artist: Taylor Swift

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload **everything inside this folder** to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose your main branch and the `/ (root)` folder.
6. Save and open the generated Pages URL.

No frameworks, npm, build step, server, or API key are required.

## Important

The page uses the supplied 736×736 artwork as the visual canvas. This keeps the original design, spacing, typography, colors, stars, text, CD artwork and proportions intact instead of trying to redraw them approximately with HTML/CSS.

The transparent CD hotspot is interactive. Once the song is playing, the vinyl/glint animation spins. Clicking the CD pauses/resumes the song.

If you replace the audio, keep the filename `assets/song.mp3` or update the `src` in `index.html`.
