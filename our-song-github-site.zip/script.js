const SONG = {
  title: "You Belong With Me",
  artist: "Taylor Swift",
  file: "assets/song.mp3"
};

const PASSWORD = "Love";

const passwordGate = document.getElementById("passwordGate");
const songPage = document.getElementById("songPage");
const passwordForm = document.getElementById("passwordForm");
const passwordInput = document.getElementById("passwordInput");
const passwordError = document.getElementById("passwordError");
const recordButton = document.getElementById("recordButton");
const audio = document.getElementById("song");
const titleEl = document.querySelector(".now-playing-title");
const artistEl = document.querySelector(".now-playing-artist");

document.title = `${SONG.title} — ${SONG.artist}`;
titleEl.textContent = SONG.title;
artistEl.textContent = SONG.artist;

function showSongPage() {
  passwordGate.classList.add("unlocked");
  passwordGate.style.transition = "opacity 450ms ease";
  passwordGate.style.opacity = "0";

  window.setTimeout(() => {
    passwordGate.hidden = true;
    songPage.hidden = false;
    document.body.style.overflow = "hidden";
  }, 450);
}

async function startSong() {
  try {
    await audio.play();
    recordButton.classList.add("playing");
    recordButton.setAttribute("aria-pressed", "true");
  } catch (error) {
    // Some browsers can still block playback; the record remains clickable.
    recordButton.classList.remove("playing");
    recordButton.setAttribute("aria-pressed", "false");
  }
}

passwordForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (passwordInput.value === PASSWORD) {
    passwordError.textContent = "";
    showSongPage();

    // The password submit is a user gesture, so start the supplied song here.
    await startSong();
  } else {
    passwordError.textContent = "That password isn't correct.";
    passwordInput.select();
  }
});

recordButton.addEventListener("click", async () => {
  if (audio.paused) {
    await startSong();
  } else {
    audio.pause();
  }
});

audio.addEventListener("play", () => {
  recordButton.classList.add("playing");
  recordButton.setAttribute("aria-pressed", "true");
});

audio.addEventListener("pause", () => {
  recordButton.classList.remove("playing");
  recordButton.setAttribute("aria-pressed", "false");
});

audio.addEventListener("ended", () => {
  recordButton.classList.remove("playing");
  recordButton.setAttribute("aria-pressed", "false");
});

passwordInput.focus();
